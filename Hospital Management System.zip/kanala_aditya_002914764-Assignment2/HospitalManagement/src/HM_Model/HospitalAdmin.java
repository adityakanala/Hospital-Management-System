/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HM_Model;

/**
 *
 * @author adity
 */
public class HospitalAdmin {
    
    String email;
    String password;

    public HospitalAdmin() {
        email = "hadmin@gmail.com";
        password = "password";
    }
     
    

    public String getEmail() {
        return email;
    }

   

    public String getPassword() {
        return password;
    }

   
    
   
    
}
