/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HM_Model;

/**
 *
 * @author adity
 */
public class House {
 
    String HNumber;

    public String getHNumber() {
        return HNumber;
    }

    public void setHNumber(String HNumber) {
        this.HNumber = HNumber;
    }
    
}
