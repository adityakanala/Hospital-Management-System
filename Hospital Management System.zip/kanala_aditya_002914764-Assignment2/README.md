# Hospital Management -- AED Assignment 2
    By Aditya Kanala
    
1. Overview
   
      This application is a platform for people to find medical resource in different city and 
  community.   
  
  <br>
  2. User Roles:
     
  The user roles include:
- System Admin: Creates, Reads, Updates, and Deletes Patiets, Doctors, Hospitals, and Encounters
- Hospital Admin: Creates, Reads, and Updates Patiets, Doctors, Hospitals, and Encounters
- Community Admin: Creates, Reads, and Updates Communities, Cities, and Houses
- Doctor: Creates, Reads, and Updates Encounters and Vital Signs
- Patient: Creates, Reads, and Updates Personal Details and Encounters
<br/>

3. UML Class Diagram

      A UML diagram is a diagram based on the UML (Unified Modeling Language) with the purpose of visually representing a system along with its main actors, roles, actions, artifacts or classes, in order to better understand, alter, maintain, or document information about the system.
    
      High Level Class Diagram :
      <br>
    <img width="453" alt="ClassDiagram" src="https://user-images.githubusercontent.com/114545333/198919664-368b63e0-46da-4b05-9259-527c6f134f0e.png">
    <br>
    <br>
      Detailed Class Diagram :
    
    <img width="491" alt="Detailed Class Diagram" src="https://user-images.githubusercontent.com/114545333/198919724-476b1ab3-c6e2-4228-a461-e04bccffef56.png">

<br>

4. Sequence Diagram 

      Sequence diagrams model the interactions between objects in a single use case.
      <br>
      <img width="755" alt="Sequence Image" src="https://user-images.githubusercontent.com/114545333/198920272-60c6501c-2bdc-44f3-909e-5c6a5372e72d.png">
      <br>
      
       System Admin Sequence Diagram :
        
      <img width="751" alt="System admin Sequence" src="https://user-images.githubusercontent.com/114545333/198925558-b544ceba-dc58-4a14-a248-dd83f4a2c88d.png">
      <br>
      
      <br>
        <br>Hospital Admin Sequence Diagram :
      <br>
      
      <img width="704" alt="Hospital Admin sequence " src="https://user-images.githubusercontent.com/114545333/198925776-f1e049d1-9a24-4098-bd7a-877da9f15cbb.png">
      <br>
      
      <br>
      <br> Community Admin Sequence Diagram :
      
      <br> <img width="509" alt="community admin sequence" src="https://user-images.githubusercontent.com/114545333/198926049-fd62084c-d2d1-4bc8-b6d5-19ad96305b46.png">
      <br>
      <br>
      <br>Doctor Sequence Diagram :
      
      <br><img width="649" alt="Doctor sequence View" src="https://user-images.githubusercontent.com/114545333/198926853-2ecf500a-a5ad-44a9-ab8f-f21aee6619f3.png">
      <br>
      <br>
      <br> Patient Sequence Diagram :
      <br> <img width="531" alt="Patient Sequence Diagram" src="https://user-images.githubusercontent.com/114545333/198927323-09860de6-e83b-4626-bdb2-be2de430ffb0.png">



